"""Configuration module for SuperManUS"""

from .settings import Settings

__all__ = ['Settings']